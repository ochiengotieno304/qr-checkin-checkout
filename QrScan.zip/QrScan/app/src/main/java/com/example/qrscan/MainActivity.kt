package com.example.qrscan

import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity : AppCompatActivity() {
    lateinit var drawer: DrawerLayout
    lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawer = findViewById(R.id.drawer_layout)

        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.nav_drawer_open, R.string.nav_drawer_close
        )
        drawer.addDrawerListener(toggle)
        toggle.syncState()


//        val qrButton: Button = findViewById(R.id.qr_button)
//        qrButton.setOnClickListener {
//            val intentIntegrator = IntentIntegrator(this)
//            setDesiredBarcodeFormats()
//            intentIntegrator.initiateScan()
//        }
    }

    @Override
    override fun onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

//    @Deprecated("Deprecated in Java")
//    @Suppress("DEPRECATION")
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        val result = IntentIntegrator.parseActivityResult(resultCode, data)
//        if (result != null) {
//            MaterialAlertDialogBuilder(this)
//                .setMessage("Would you like to go to ${result.contents}?")
//                .setPositiveButton("Yes") { _, _ ->
//                    val intent = Intent(Intent.ACTION_WEB_SEARCH)
//                    intent.putExtra(SearchManager.QUERY, result.contents)
//                    startActivity(intent)
//                }
//                .setNegativeButton("No") { _, _ -> }
//                .create()
//                .show()
//        }
//    }
}

//private fun setDesiredBarcodeFormats() {
//
//}
